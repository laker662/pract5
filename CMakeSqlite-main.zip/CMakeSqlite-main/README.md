# CMakeSqlite
CMake + Sqlite + docker + ansible
